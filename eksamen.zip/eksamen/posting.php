<?php

function posting($db) {
    $postTitle = $_POST['postTitle'];
    $postAuthor = $_POST['postAuthor'];
    $postText = $_POST['postText'];
    $postTags = $_POST['postTags'];
    $postDate = $_POST['postDate'];

    //Insert the post data to db
    if ($postTitle != "" ) {
    $sql = "INSERT INTO post (postTitle, postAuthor, postText, postTags, postDate) VALUES ('$postTitle', '$postAuthor', '$postText', '$postTags', '$postDate')";
    $result = $db->sql($sql, [], false);
    header("Location: index.php");
    };
}