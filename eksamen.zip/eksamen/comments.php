<?php

function setComments($db) {
    $userId = $_POST['userId'];
    $date = $_POST['date'];
    $comment = $_POST['comment'];
    $pageId = $_POST['pageId'];

    $sql = "INSERT INTO comments(userId, date, comment, pageId) VALUES ('$userId', '$date', '$comment', '$pageId')";
    $result = $db->sql($sql, [], false);
}


function getComments($db, $postId) {

    $sql = "SELECT * FROM comments WHERE pageId = :postId";
    $bind = [":postId" => $postId];
    $result = $db->sql($sql, $bind);

    //var_dump($result); exit;

    foreach ($result as $row){

        echo "<div class='card mt-2 col-md-8 pb-3'> <div class='card'>". "<h5 class='card-title'>" . $row->userId . "</h5>" . "<p class='card-text'>" . $row->date . "</p>" . "<p class='card-text'>" . nl2br($row->comment) . "</p> 
        

        <div class='d-flex justify-content-between'>
        
        <form method='POST' action='editComment.php'>
        <input type='hidden' name='cid' value=".$row->cid.">
        <input type='hidden' name='userId' value=".$row->userId.">
        <input type='hidden' name='date' value=".$row->date.">
        <input type='hidden' name='comment' value='". nl2br($row->comment) ."'>
        <button class='btn btn-primary' name='edit'>Edit</button>
        </form> 
        
        <form method='POST' action='". deleteComments($db) ."'>
        <input type='hidden' name='cid' value=".$row->cid.">
        <button class='btn btn-danger' type='submit' name='commentDelete'>Slet</button>
        </form> 
        
        </div>
        </div>
        </div>";

    }


}

function deleteComments($db) {
    if (isset($_POST['commentDelete'])) {
        $cid = $_POST['cid'];

        $sql = "DELETE FROM comments WHERE cid='$cid'";
        $result = $db->sql($sql, [], false);
        header("Location: index.php");
    }
}