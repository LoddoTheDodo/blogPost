<?php
/** @var PDO $db */
require "settings/init.php";

$postId = $_GET["postId"];
$post = $db->sql("SELECT * FROM post WHERE postId = :postId", [":postId" => $postId]);
$post = $post[0];
date_default_timezone_set('Europe/Copenhagen');
include 'comments.php';
include 'elements.php';

if($_SERVER["REQUEST_METHOD"] == "POST"){
    setComments($db);
}
?>
<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="utf-8">
    <title>Cool Kryb</title>
    <meta name="robots" content="All">
    <meta name="author" content="Udgiver">
    <meta name="copyright" content="Information om copyright">
    <link href="css/styles.css" rel="stylesheet" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body class="d-flex flex-column min-vh-100">

<?php
nav();
?>

<div class="container mt-4 flex-grow-1">
    <div class="row">
        <main class="col-md-8">
            <article>
                <?php
                echo "<h1 class='text-primary'>" . $post->postTitle . "</h1>";
                echo
                    "
                    <strong>Date:</strong> " . date('\d. d-m-Y \k\l. H:i', strtotime($post->postDate)) . "         
                    <div class='d-flex justify-content-between'>
                    <form method='POST' action='". deletePosts($db) ."'>
                    <input type='hidden' name='postId' value=". ($post->postId) .">
                    <button class='btn btn-danger' type='submit' name='postDelete'>Slet</button>
                    </form> 

                    </div>
                    <br><br>";
                echo "<p>" . $post->postText . "</p>";

                function deletePosts($db) {

                    if (isset($_POST['postDelete'])) {
                        $postId  = $_POST['postId'];

                        $sql = "DELETE FROM post WHERE postId='$postId '";
                        $result = $db->sql($sql, [], false);
                        header("Location: index.php");
                    }
                }
                ?>
            </article>

            <div class="mt-4">
                <h4>Comments</h4>
                <?php
                echo "<form class='form-group' method='POST' action=''>
                    <input type='hidden' name='pageId' value='$postId'>
                    <input type='hidden' name='userId' value='anon'>
                    <input type='hidden' name='date' value='".date('Y-m-d H:i:s')."'>
                    <textarea class='form-control' placeholder='Kommentar' name='comment' rows='5'></textarea>
                    <button type='submit' name='submitComment' class='btn btn-primary'>Send</button>
                </form>";
                getComments($db, $_GET['postId']);



                ?>
            </div>
        </main>

        <?php
        sideBar();
        ?>
    </div>
</div>

<?php
footer();
?>


<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>