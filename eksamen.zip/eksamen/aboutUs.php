<?php
/** @var PDO $db */
require "settings/init.php";
include 'posting.php';
include 'elements.php';
?>
<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="utf-8">
    <title>Cool Kryb</title>
    <meta name="robots" content="All">
    <meta name="author" content="Udgiver">
    <meta name="copyright" content="Information om copyright">
    <link href="css/styles.css" rel="stylesheet" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php
nav();
?>

<div class="container mt-4">
    <div class="row">
        <main class="col-md-8">
            <h1 class="text-primary">Om Os</h1>
            <p>Velkommen til Insektverdenen! Vi er et passioneret team af entomologer, naturforskere og insektentusiaster, der ønsker at dele vores fascination for insekter med dig. Vores mission er at oplyse, inspirere og skabe en dybere forståelse for disse utrolige væsener, der spiller en vital rolle i vores økosystemer.</p>

            <h3>Hvad Handler Vores Blog Om?</h3>
            <p>På Insektverdenen dækker vi alt fra almindelige haveinsekter til mere eksotiske arter. Vi udforsker deres livscyklusser, adfærd, og den vigtige funktion, de har i naturen – fra bestøvning af planter til nedbrydning af organisk materiale.</p>

            <h3>Vores Vision</h3>
            <p>Vi stræber efter at gøre videnskab tilgængelig og interessant for alle, uanset alder eller baggrund. Gennem informative artikler, billeder og videoer ønsker vi at vise, hvor fantastiske insekter virkelig er. Vores mål er at fremme bevidsthed om, hvordan vi kan beskytte og bevare disse små, men vigtige skabninger.</p>

            <h3>Mød Teamet</h3>
            <ul>
                <li><strong>Anna</strong> - Entomolog og skribent. Anna har en MSc i Biologi med speciale i insektadfærd.</li>
                <li><strong>Thomas</strong> - Naturfotograf og ivrig insektjæger. Thomas fanger øjeblikke fra insekternes verden med sit kamera.</li>
                <li><strong>Sofia</strong> - Uddannelsesekspert og blogger. Sofia udvikler undervisningsmateriale til både børn og voksne.</li>
            </ul>

            <h3>Bliv En Del Af Fællesskabet</h3>
            <p>Vi inviterer dig til at blive en del af vores voksende fællesskab. Del dine egne insektopdagelser, stille spørgsmål, eller kommenter på vores indlæg.</p>

            <h3>Kontakt Os</h3>
            <p>Har du spørgsmål eller forslag? Tøv ikke med at kontakte os via vores kontaktformular. Vi elsker at høre fra vores læsere!</p>

            <p>Tak fordi du besøger Insektverdenen – vi håber, du finder inspiration og ny viden her!</p>
        </main>

        <?php
        sideBar();
        ?>
    </div>
</div>

<?php
footer();
?>


<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>