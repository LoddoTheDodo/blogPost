<?php
/** @var PDO $db */
require "settings/init.php";

include 'comments.php';
include 'elements.php';

$postId = $_GET["postId"];
$post = $db->sql("SELECT * FROM post WHERE postId = :postId", [":postId" => $postId]);
$post = $post[0];
?>
<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="utf-8">

    <title>Cool Kryb</title>

    <meta name="robots" content="All">
    <meta name="author" content="Udgiver">
    <meta name="copyright" content="Information om copyright">

    <link href="css/styles.css" rel="stylesheet" type="text/css">

    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
<?php
nav();
?>

<div class="container mt-4">
    <div class="row">
        <div class="col-md-8">


        <?php
        $postDate = $_POST['postDate'];
        $postText = $_POST['postText'];
        $postId = $_POST['postId'];



        echo "
            <div class='col-md-8'>
                <form class='form-group ' method='POST' action=''>

                <input type='hidden' name='postId' value='".$postId."'>
                <input type='hidden' name='postDate' value='". $postDate ."'>
                <h3>Post</h3>
                <textarea class='form-control' placeholder='Text' name='postText' rows='5'>". $postText ."</textarea>
                
                <button type='submit' name='submitPost' class='btn btn-primary'>Send</button>
            </form>
            </div>";
        editPost($db);

        function editPost($db) {
            if (isset($_POST['submitPost'])) {
                $postDate = $_POST['postDate'];
                $postText = $_POST['postText'];
                $postId = $_POST['postId'];

                $sql = "UPDATE post SET postText='$postText' WHERE postId='$postId'";
                $result = $db->sql($sql, [], false);
                header("Location: index.php");
            }
        }
        ?>
        </div>
    </div>
</div>


<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>