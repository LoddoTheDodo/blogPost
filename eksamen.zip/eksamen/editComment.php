<?php
/** @var PDO $db */
require "settings/init.php";

include 'comments.php';
include 'elements.php';

$postId = $_GET["postId"];
$post = $db->sql("SELECT * FROM post WHERE postId = :postId", [":postId" => $postId]);
$post = $post[0];
?>
<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="utf-8">

    <title>Cool Kryb</title>

    <meta name="robots" content="All">
    <meta name="author" content="Udgiver">
    <meta name="copyright" content="Information om copyright">

    <link href="css/styles.css" rel="stylesheet" type="text/css">

    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>
<?php
nav();
?>

<div class="container mt-4">
    <div class="row">
        <?php
        $cid = $_POST['cid'];
        $userId = $_POST['userId'];
        $date = $_POST['date'];
        $comment = $_POST['comment'];



        echo "<form class='form-group  mt-6' method='POST' action=''>
                <h5>Navn</h5>
                <input type='hidden' name='userId' value='".$userId."'>
                <input type='hidden' name='cid' value='".$cid."'>
                <p>Dato</p>
                <input type='' name='date' value='". $date ."'>
                <p>Kommentar</p>
                <textarea class='form-control' placeholder='Kommentar' name='comment' rows='5'>". $comment ."</textarea>
                
                <button type='submit' name='submitComment' class='btn btn-primary'>Send</button>
            </form>";
        editComment($db);

        function editComment($db) {
        if (isset($_POST['submitComment'])) {
            $userId = $_POST['userId'];
            $date = $_POST['date'];
            $comment = $_POST['comment'];
            $cid = $_POST['cid'];

            $sql = "UPDATE comments SET comment='$comment' WHERE cid='$cid'";
            $result = $db->sql($sql, [], false);
            header("Location: index.php");
        }
        }
        ?>
    </div>
</div>


<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>