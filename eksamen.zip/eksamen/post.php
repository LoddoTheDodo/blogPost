<?php
/** @var PDO $db */
require "settings/init.php";
include 'posting.php';
include 'elements.php';
?>
<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="utf-8">

    <title>Cool Kryb</title>

    <meta name="robots" content="All">
    <meta name="author" content="Udgiver">
    <meta name="copyright" content="Information om copyright">

    <link href="css/styles.css" rel="stylesheet" type="text/css">

    <meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>
<?php
nav();
?>

<div class="container mt-4">
    <div class="row">
        <main class="col-md-8">

            <h2>Create a New Post</h2>
            <?php
            echo "<form method='POST' action=''>
                <div class='form-group'>
                    <label for='postTitle'>Title</label>
                    <input type='text' class='form-control' id='postTitle' name='postTitle'>
                </div>
                <div class='form-group'>
                    <label for='postAuthor'>Author</label>
                    <input type='text' class='form-control' id='postAuthor' name='postAuthor'>
                </div>
                <div class='form-group'>
                    <label for='postText'>Content</label>
                    <textarea class='form-control' id='postText' name='postText' rows='5'></textarea>
                </div>
                <div class='form-group'>
                    <label for='postTags'>Tags</label>
                    <input type='text' class='form-control' id='postTags' name='postTags' placeholder='Comma separated'>
                </div>
                <button type='submit' class='btn btn-primary' name='submitPost'>Post Article</button>
                

                <input type='hidden' name='postDate' value='".date('Y-m-d H:i:s')."'>
            </form>";
                posting($db);
            ?>
        </main>

        <?php
        sideBar();
        ?>
    </div>
</div>

<?php
footer();
?>


<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>