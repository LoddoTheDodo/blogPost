-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 08, 2024 at 01:40 PM
-- Server version: 8.3.0
-- PHP Version: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eksamdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `userId` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `date` datetime NOT NULL,
  `comment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `pageId` int NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`cid`, `userId`, `date`, `comment`, `pageId`) VALUES
(73, '', '0000-00-00 00:00:00', '', 0),
(74, '', '0000-00-00 00:00:00', '', 0),
(75, '', '0000-00-00 00:00:00', '', 0),
(76, '', '0000-00-00 00:00:00', '', 0),
(77, '', '0000-00-00 00:00:00', '', 0),
(79, 'anon', '2024-10-08 15:37:02', 'Det er nice at jeg kan kommentere her der og alle vejne!!', 35),
(80, '', '0000-00-00 00:00:00', '', 0),
(68, '', '0000-00-00 00:00:00', '', 0),
(69, '', '0000-00-00 00:00:00', '', 0),
(70, '', '0000-00-00 00:00:00', '', 0),
(71, '', '0000-00-00 00:00:00', '', 0),
(72, '', '0000-00-00 00:00:00', '', 0),
(67, '', '0000-00-00 00:00:00', '', 0),
(65, '', '0000-00-00 00:00:00', '', 0),
(66, '', '0000-00-00 00:00:00', '', 0),
(64, '', '0000-00-00 00:00:00', '', 0),
(62, '', '0000-00-00 00:00:00', '', 0),
(60, '', '0000-00-00 00:00:00', '', 0),
(59, 'anon', '2024-10-08 01:05:13', 'De er godt nok cool', 33),
(63, '', '0000-00-00 00:00:00', '', 0),
(78, 'anon', '2024-10-08 02:53:31', 'Cool stuff', 31);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE IF NOT EXISTS `post` (
  `postId` int NOT NULL AUTO_INCREMENT,
  `postTitle` varchar(200) NOT NULL,
  `postAuthor` int NOT NULL,
  `postText` text NOT NULL,
  `postDate` datetime NOT NULL,
  `postTags` varchar(255) NOT NULL,
  PRIMARY KEY (`postId`),
  KEY `postAuthor` (`postAuthor`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`postId`, `postTitle`, `postAuthor`, `postText`, `postDate`, `postTags`) VALUES
(31, 'Bier: Naturens Uundgåelige Helte', 0, 'Bier er ikke bare små insekter; de spiller en afgørende rolle i vores økosystem og landbrug. Uden dem ville mange af de fødevarer, vi nyder, være svære at finde, og vores naturlige miljø ville lide. I denne blogpost vil vi dykke ned i biernes fascinerende verden, deres betydning og hvordan vi kan beskytte dem.\r\n\r\nBier er en af de mest effektive bestøvere, der findes. Når de besøger blomster for at samle nektar og pollen, overfører de pollen fra blomst til blomst. Denne proces er essentiel for mange planter, da den muliggør befrugtning og produktion af frugter og frø. Faktisk er det anslået, at en tredjedel af den mad, vi spiser, afhænger af bestøvning af insekter, hvoraf bier står for en stor del.', '2024-10-07 20:58:08', 'bier,'),
(33, 'Myrer: Naturens Flittige Arbejdere', 0, 'Myrer er fascinerende væsner, der spiller en vigtig rolle i vores økosystem. Selvom de ofte bliver set som irriterende skadedyr, er deres bidrag til naturen og vores samfund uundgåelige. I denne blogpost vil vi udforske myrernes verden, deres unikke samfundsstruktur og hvordan de påvirker miljøet.', '2024-10-07 20:58:34', 'myre'),
(35, 'Tusindeben - fascinerende krybdyr', 0, 'Tusindeben er fascinerende krybdyr, der findes i mange forskellige former og størrelser. De fleste tusindeben har mellem 20 og 400 ben, men nogle arter kan have op til 750 ben! Tusindeben er normalt sorte, brune eller grå, men nogle arter kan være farverige.\r\n\r\nTusindeben er normalt nataktive og kan ofte findes under sten, træstammer eller i løv. De er ikke giftige, men nogle arter kan udskille et irriterende stof fra deres ben.\r\n\r\nTusindeben er vigtige for økosystemet, da de hjælper med at nedbryde dødt organisk materiale. De er også en fødekilde for mange forskellige dyr, såsom fugle, frøer og insekter.', '2024-10-07 21:00:36', 'ben, insekter'),
(37, 'Alt om Korsedderkopper: Naturens Fascinerende Spindlere', 0, 'Korsedderkoppen (Araneidae) er en af de mest genkendelige og interessante edderkopper i Danmark. Med sit karakteristiske korsformede mønster på bagkroppen og sine dygtige spindefærdigheder har den fanget mange menneskers fascination. I denne blogpost dykker vi ned i korsedderkoppens liv, dens betydning i økosystemet, og nogle sjove fakta, som du sikkert ikke kendte!\r\n\r\nUdseende og Kendetegn\r\nKorsedderkoppen varierer i størrelse og farve, men de fleste arter har et tydeligt mønster på ryggen, der ligner et kors. Dette mønster fungerer ikke kun som camouflage, men kan også skræmme potentielle rovdyr. De har lange ben, der hjælper dem med at navigere i deres spind og fangstmetoder.', '2024-10-07 21:09:04', 'edderkop, ben, '),
(38, 'Myggen: Naturens Uønskede Blodsuger', 0, 'Myggen: Naturens Uønskede Blodsuger\r\n\r\nMyggen er en af de mest genkendelige og ofte irriterende skabninger i vores hverdag. Med deres karakteristiske summen og evne til at forfølge os, har de gjort sig bemærket i både byer og natur. I denne blogpost dykker vi ned i myggens livscyklus, dens rolle i økosystemet, og hvordan vi bedst kan håndtere disse små blodsugere.\r\n\r\n\r\nUdseende og Kendetegn\r\nMyg er små, slanke insekt med lange ben og en karakteristisk proboscis, som de bruger til at suge blod. De fleste myg har en længde på 3-6 mm, og deres kroppe kan variere i farve fra grå til sort. Hunnens proboscis er især lang og skarp, hvilket gør det muligt for den at trænge ind i huden og suge blod.', '2024-10-07 21:12:14', 'blod,');

-- --------------------------------------------------------

--
-- Table structure for table `userlist`
--

DROP TABLE IF EXISTS `userlist`;
CREATE TABLE IF NOT EXISTS `userlist` (
  `authorId` int NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
