<?php
/** @var PDO $db */
require "settings/init.php";
include 'elements.php';

function getPostsByTags($db, $searchedTitle) {
    $sql = "SELECT * FROM post WHERE postTitle LIKE concat('%', ':searchedTitle', '%') OR postTags LIKE concat('%', ':searchedTitle', '%')";
    return $sql;
}


//Matching tags or nahh
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $posts = getPostsByTags($_POST["search"]);
} else {
    //If no tags are provided kill
    $posts = "";
}
?>
<!DOCTYPE html>
<html lang="da">
<head>
    <meta charset="utf-8">

    <title>My blog</title>

    <meta name="robots" content="All">
    <meta name="author" content="Udgiver">
    <meta name="copyright" content="Information om copyright">

    <link href="css/styles.css" rel="stylesheet" type="text/css">

    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>

<?php
nav();
?>

<div class="container mt-4">
    <div class="row">
        <main class="col-md-8">
            <main class="col-md-8">
                <?php
                foreach ($posts as $post) {
                    ?>
                    <div class="col-12 col-md-12">
                        <div class="card w-100">
                            <div class="card-header bg-primary text-light py-3">
                                <?php
                                echo "<h2 class='m-0'>".$post->evenName;
                                ?>
                            </div>
                            <div class="container">
                                <?php
                                echo "<h3>" . $post->postTitle . "</h3><br>";
                                echo "<p class='text-muted'>" . $post->postTags . "</p>";
                                echo $post->postText;

                                echo "<div class='mt-2'><div class='badge bg-secondary fw-light py-2 px-3 text-dark' style='font-size: 14px;'>" . date('\d. d-m-Y \k\l. H:i', strtotime($post->postDate)) . "</div></div>";
                                ?>
                            </div>
                            <div class="card-footer text-muted text-center">
                                <a class="btn btn-primary text-light stretched-link" href="article.php?postId=<?php echo $post->postId; ?>" role="button">Læs mere</a>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </main>
        </main>

        <?php
        sideBar();
        ?>
    </div>
</div>

<?php
footer();
?>


<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>