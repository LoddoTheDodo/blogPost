# Kickstarter projekt med PHP

Download projektet som ZIP-fil

- Åben projektet og kør kommandoen "npm install" i terminalen
- Kør "sass" kommandoen fra npm scripts.
  
Du kan find npm scripts ved at dobbeltrykke på shift, på dit tastatur og søge. Alternativt kan du skrive "npm run sass" i terminalen
