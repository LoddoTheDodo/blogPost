<?php

function nav() {
echo "<nav class='p-lg-2 navbar navbar-expand-lg navbar-dark bg-dark'>
    <a class='navbar-brand' href='index.php'>Cool Kryb</a>
    <div class='collapse navbar-collapse justify-content-between' id='navbarNav'>
        <ul class='navbar-nav'>
            <li class='nav-item active'>
                <a class='nav-link' href='post.php'>Ny Post</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='aboutUs.php'>Om os</a>
            </li>
        </ul>
        <form class='form-inline my-2 my-lg-0'>
            <input class='form-control mr-sm-2' type='search' placeholder='Søg' id='search'>
        </form>
    </div>
</nav>";
}

function sideBar() {
    echo "<aside class='col-md-3 bg-dark text-light'>
            <h4 class='mb-3 pt-3'>Om os</h4>
            <p>Insektverdenen udforsker insekters fascinerende liv og betydning. Oplev naturens små vidundere med os!</p>

            <h4 class='mb-3'>Populære Tags</h4>
            <li><a href='#'>Ben</a></li>
            <li><a href='#'>Bier</a></li>
            <li><a href='#'>Blod</a></li>

        </aside>";
}

function footer() {
    echo "<footer class='footer bg-dark text-center mt-4'>
        <div class='container'>
        <span class='text-light'>© 2024 My Blog</span>
        </div>
    </footer>";
}
?>