<?php
/** @var PDO $db */
require "settings/init.php";

include 'elements.php';

$postId = $_GET["postId"];
$post = $db->sql("SELECT * FROM post WHERE postId = :postId", [":postId" => $postId]);
$post = $post[0];
?>
<!DOCTYPE html>
<html lang="da">
<head>
	<meta charset="utf-8">
	
	<title>Cool Kryb</title>
	
	<meta name="robots" content="All">
	<meta name="author" content="Udgiver">
	<meta name="copyright" content="Information om copyright">
	
	<link href="css/styles.css" rel="stylesheet" type="text/css">
	
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>

<body>

<?php
    nav();
?>

<div class="container mt-4">
    <div class="row">
        <main class="col-md-8">
            <h2 class="mb-4">Latest Posts</h2>

            <article>
                <div class="row">
                    <?php
                    $posts = $db->sql("SELECT * FROM post ORDER BY postDate ASC");
                    foreach($posts as $post) {
                        $first25Words = implode(' ', array_slice(explode(' ', $post->postText), 0, 25));
                        ?>
                        <div class="col-12 col-md-6 d-flex mb-4">
                            <div class="card w-100 d-flex flex-column">
                                <div class="card-header bg-primary text-light py-3">
                                    <?php
                                    echo "<h2 class='m-0'>".$post->evenName."</h2>";
                                    ?>
                                </div>
                                <div class="container flex-grow-1">
                                    <h3><?php echo $post->postTitle; ?></h3>
                                    <p class='text-muted'><?php echo $post->postTags; ?></p>
                                    <p><?php echo $first25Words . "..."; ?></p>
                                </div>
                                <div class="card-footer text-muted text-center">
                                    <div class="badge bg-secondary fw-light py-2 px-3 text-dark" style='font-size: 14px;'>
                                        <?php echo date('\d. d-m-Y \k\l. H:i', strtotime($post->postDate)); ?>
                                    </div>
                                    <a class="btn btn-primary text-light stretched-link mt-2" href="article.php?postId=<?php echo $post->postId; ?>" role="button">Læs mere</a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </article>
        </main>

        <?php
        sideBar();
        ?>
    </div>
</div>
<?php
footer();
?>


<script src="node_modules/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>